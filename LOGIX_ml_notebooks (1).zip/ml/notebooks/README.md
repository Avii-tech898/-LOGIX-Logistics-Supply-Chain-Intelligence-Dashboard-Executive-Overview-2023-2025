# LOGIX ML Notebooks

1. `01_delivery_delay_eda.ipynb` — Delivery-delay exploratory analysis
2. `02_delivery_delay_feature_engineering.ipynb` — Time-aware feature engineering
3. `03_delivery_delay_model_training.ipynb` — Baseline model training
4. `04_delivery_delay_model_evaluation.ipynb` — Actual test-set evaluation

Run Jupyter from the LOGIX repository root.
